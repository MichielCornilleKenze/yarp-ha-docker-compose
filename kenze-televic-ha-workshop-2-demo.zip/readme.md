dotnet build .\client\client.csproj
dotnet build .\apigateway\ApiGateway.csproj
dotnet build .\service1\Service1.csproj

docker compose up


nog naar miro kopieren: 
https://www.milanjovanovic.tech/blog/horizontally-scaling-aspnetcore-apis-with-yarp-load-balancing
![alt text](image.png)